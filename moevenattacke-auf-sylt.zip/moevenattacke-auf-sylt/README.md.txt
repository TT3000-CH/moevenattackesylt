# Möwenattacke auf Sylt

Ein kleines 2D‑Browsergame mit Phaser 3.

## Idee

Du spielst eine Möwe am Strand von Sylt und klaust Tourist:innen Glace und Burger aus der Hand.  
Zusätzliche Items:
- Pommes: +5 Punkte
- Zitrone: −3 Punkte

3 Leben, langsam steigende Schwierigkeit, Comic‑Stil.

## Steuerung

- **Maus / Touch:** Klick / Tap auf die gewünschte Position → Möwe fliegt dorthin.
- **R:** Neustart nach Game Over.

## Entwicklung

1. Repo klonen oder Dateien in einen Ordner kopieren.
2. Lokaler Server, z.B.:

   ```bash
   npx http-server
   # oder
   python -m http.server 8000
